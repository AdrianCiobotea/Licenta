package com.example.demo.repository;

import com.example.demo.entity.SubOrder;
import org.springframework.data.repository.CrudRepository;

public interface SubOrderRepository extends CrudRepository<SubOrder, Integer> {
}
