insert into user (phone_number,password,user_role) values (
"123456789" , "$2a$12$egz45bYA2U0ygnibsvc1xujGWF3UUo3/a4r9wf3E9il84RoxYrUFW" , "CLIENT"
);